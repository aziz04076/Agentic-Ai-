# EWS Baseline Model Card

## Model Overview
- **Model**: Baseline heuristic logistic mapping of engineered features
- **Version**: baseline-0.1
- **Task**: Early warning risk scoring for student disengagement
- **Created**: 2024-01-01

## Features
- `attendance_rate_14d`: Student attendance rate over 14 days
- `login_streak_delta`: Change in consecutive login days
- `missing_assignments_14d`: Number of missing assignments in 14 days
- `avg_grade_delta_28d`: Change in average grade over 28 days
- `late_ratio_14d`: Ratio of late submissions in 14 days
- `sentiment_mean_14d`: Average sentiment score over 14 days

## Performance Metrics
- **Target AUC**: ≥ 0.80 on sample data
- **Calibration**: Brier score and calibration summary provided
- **Precision/Recall**: Computed by probability buckets
- **Fairness**: Subgroup metrics by demographic groups

## Model Limitations
- This is a synthetic baseline model for demonstration
- Replace with trained LightGBM in production
- Features are simplified for initial implementation
- Real-world performance may vary significantly

## Privacy & Ethics
- **PII Handling**: Minimal PII storage, audit logging enabled
- **Bias Monitoring**: Subgroup fairness metrics tracked
- **Data Minimization**: Only necessary features collected
- **Transparency**: SHAP explanations provided for predictions

## Usage
```python
# Load and use the model
import pickle
with open('ml/artifacts/ews_lgbm.pkl', 'rb') as f:
    model = pickle.load(f)

# Predict risk for a student
features = [0.9, -1.0, 2.0, -0.1, 0.3, 0.7]
risk_score = model.predict_proba([features])[0]
```

## Training Data
- **Size**: 1000 synthetic samples
- **Features**: 6 engineered features
- **Labels**: Binary (0=low risk, 1=high risk)
- **Distribution**: Balanced classes

## Evaluation
Run evaluation with:
```bash
python -m ml.evaluate
```

This will generate:
- AUC and Average Precision scores
- Calibration metrics
- Precision/recall by buckets
- Subgroup fairness analysis
