from __future__ import annotations

"""Model evaluation utilities and fairness report."""

import json
from typing import Any

import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, roc_auc_score

from app.services.eval import calibration_summary, compute_precision_recall_by_bucket, group_fairness_metrics


def evaluate_df(df: pd.DataFrame, prob_col: str, label_col: str) -> dict[str, Any]:
    auc = roc_auc_score(df[label_col], df[prob_col])
    ap = average_precision_score(df[label_col], df[prob_col])
    cal = calibration_summary(df[label_col].tolist(), df[prob_col].tolist())
    buckets = compute_precision_recall_by_bucket(df[label_col].tolist(), df[prob_col].tolist())
    fairness = group_fairness_metrics(df, prob_col, label_col, group_cols=["group"])
    return {"auc": float(auc), "average_precision": float(ap), "calibration": cal, "buckets": buckets, "fairness": fairness}


def main() -> None:
    rng = np.random.default_rng(7)
    n = 500
    df = pd.DataFrame({
        "p": rng.uniform(0, 1, n),
        "y": rng.integers(0, 2, n),
        "group": rng.choice(["A", "B"], size=n),
    })
    report = evaluate_df(df, "p", "y")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()


