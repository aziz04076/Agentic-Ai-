from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException

from app.deps import require_role
from app.db.schemas import RiskOut

router = APIRouter(tags=["students"])


@router.get("/students/{student_id}/risk", response_model=RiskOut)
def get_student_risk(student_id: str, _: dict = Depends(require_role("educator"))):
    """
    Example response:
    {"student_id":"s1","probability":0.72,"label":"high","as_of_date":"..","model_version":"..","explanations":{}}
    """
    # Placeholder: deterministic response
    if not student_id:
        raise HTTPException(status_code=404, detail="student not found")
    return RiskOut(
        student_id=student_id,
        probability=0.5,
        label="medium",
        as_of_date="2024-01-01T00:00:00Z",
        model_version="baseline-0.1",
        explanations={"attendance_rate_14d": 0.9},
    )


