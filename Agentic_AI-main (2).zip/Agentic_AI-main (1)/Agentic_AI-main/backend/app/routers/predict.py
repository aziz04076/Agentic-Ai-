from __future__ import annotations

from datetime import datetime
from typing import Annotated

from fastapi import APIRouter, Depends

from app.deps import require_role
from app.services.langgraph_pipeline import run_once

router = APIRouter(tags=["predict"])


@router.post("/predict/run")
def predict_run(_: Annotated[dict, Depends(require_role("analyst"))]):
    """
    Example request: {"since": null}
    Example response: {"notify_result": {..}}
    """
    result = run_once(since=None)
    return result


