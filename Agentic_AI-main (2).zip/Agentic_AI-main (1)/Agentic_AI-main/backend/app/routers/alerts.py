from __future__ import annotations

from typing import Annotated

from fastapi import APIRouter, Depends, WebSocket, WebSocketDisconnect

from app.deps import require_role

router = APIRouter(tags=["alerts"])


@router.websocket("/alerts/stream")
async def alerts_stream(ws: WebSocket):
    await ws.accept()
    try:
        await ws.send_json({"type": "welcome", "message": "alert stream connected"})
        # Placeholder push
        await ws.send_json({"type": "alert", "message": "Sample alert", "severity": "medium"})
    except WebSocketDisconnect:
        return


