from __future__ import annotations

from datetime import datetime
from typing import Annotated

from fastapi import APIRouter, Depends

from app.deps import require_role
from app.services.langgraph_pipeline import run_once

router = APIRouter(tags=["ingest"])


@router.post("/ingest/events")
def ingest_events(_: Annotated[dict, Depends(require_role("analyst"))]):
    """
    Example request: {}
    Example response: {"status":"ok"}
    """
    run_once(since=None)
    return {"status": "ok"}


