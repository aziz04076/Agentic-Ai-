from __future__ import annotations

from datetime import timedelta

from fastapi import APIRouter, HTTPException

from app.core.auth import create_access_token, get_password_hash, verify_password
from app.db.schemas import LoginRequest, TokenResponse

router = APIRouter(tags=["auth"])


@router.post("/login", response_model=TokenResponse)
def login(payload: LoginRequest) -> TokenResponse:
    """
    OAuth2 password flow mock. In production, verify from DB.
    Example request: {"email":"educator@example.com","password":"password"}
    """
    # Demo users by email domain
    role = "educator"
    if payload.email.startswith("admin"):
        role = "admin"
    elif payload.email.startswith("analyst"):
        role = "analyst"
    elif payload.email.startswith("student"):
        role = "student"

    # For demo, accept any non-empty password
    if not payload.password:
        raise HTTPException(status_code=400, detail="Invalid credentials")

    token = create_access_token(
        subject=payload.email,
        expires_delta=timedelta(minutes=60 * 24),
        extra={"role": role, "email": payload.email},
    )
    return TokenResponse(access_token=token)


