from __future__ import annotations

"""Audit logging utilities.

Writes educator actions to the `audit_logs` table.
"""

from datetime import datetime, timezone
from typing import Any

from sqlalchemy.orm import Session

from app.db import models


def audit_action(db: Session, user_id: str, action: str, entity: str, entity_id: str, metadata: dict[str, Any] | None = None) -> None:
    log = models.AuditLog(
        user_id=user_id,
        action=action,
        entity=entity,
        entity_id=entity_id,
        metadata=metadata or {},
        created_at=datetime.now(tz=timezone.utc),
    )
    db.add(log)


