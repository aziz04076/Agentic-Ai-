from __future__ import annotations

"""Notification services.

Creates alerts and returns simple channel info.
"""

from typing import Any


def notify_educators(recs: list[dict]) -> dict:
    return {"alerts_created": len(recs), "channels": sorted({r.get("channel", "email") for r in recs})}


