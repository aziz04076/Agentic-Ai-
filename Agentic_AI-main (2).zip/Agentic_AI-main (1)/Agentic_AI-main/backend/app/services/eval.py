from __future__ import annotations

"""Evaluation helpers for precision/recall buckets, calibration, and fairness."""

from typing import Any

import numpy as np
import pandas as pd


def compute_precision_recall_by_bucket(y_true: list[int], y_prob: list[float]) -> dict:
    df = pd.DataFrame({"y": y_true, "p": y_prob})
    df["bucket"] = pd.qcut(df["p"], 5, labels=False, duplicates="drop")
    agg = df.groupby("bucket").apply(lambda g: {
        "n": int(len(g)),
        "pos": int(g["y"].sum()),
        "precision": float(g["y"].mean()) if len(g) else 0.0,
        "avg_p": float(g["p"].mean()) if len(g) else 0.0,
    })
    return {int(k): v for k, v in agg.to_dict().items()}


def calibration_summary(y_true: list[int], y_prob: list[float]) -> dict:
    y = np.array(y_true)
    p = np.array(y_prob)
    return {
        "brier_score": float(np.mean((p - y) ** 2)),
        "avg_pred": float(p.mean()),
        "avg_true": float(y.mean()),
    }


def group_fairness_metrics(df: pd.DataFrame, prob_col: str, label_col: str, group_cols: list[str]) -> dict:
    out: dict[str, Any] = {}
    for g in group_cols:
        agg = df.groupby(g).apply(lambda x: {
            "n": int(len(x)),
            "pos_rate": float(x[label_col].mean()) if len(x) else 0.0,
            "avg_score": float(x[prob_col].mean()) if len(x) else 0.0,
        })
        out[g] = agg.to_dict()
    return out


