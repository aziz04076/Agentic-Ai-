from __future__ import annotations

"""Intervention recommendation services.
"""

from typing import Any


def retrieve_playbook(tag: str) -> list[dict]:
    return [
        {"template": "Email guardian about {student_name}", "channel": "email"},
        {"template": "Schedule 1:1 check-in for {student_name}", "channel": "meeting"},
    ]


def llm_personalize(template: str, student_ctx: dict) -> dict:
    subject = f"Support plan for {student_ctx.get('student_name', 'student')}"
    body = template.format(**student_ctx)
    return {"subject": subject, "body": body}


def counterfactual_check(rec: dict) -> bool:
    return True


def recommend_interventions(risks: list[dict], signals: dict[str, list[dict]]) -> list[dict]:
    recs: list[dict] = []
    for r in risks:
        sid = r["student_id"]
        plays = retrieve_playbook("login_drop")
        ctx = {
            "student_name": sid,
            "probability": f"{r['probability']:.2f}",
            "label": r["label"],
        }
        for p in plays:
            msg = llm_personalize(p["template"], ctx)
            rec = {"student_id": sid, "channel": p["channel"], **msg}
            if counterfactual_check(rec):
                recs.append(rec)
    return recs


