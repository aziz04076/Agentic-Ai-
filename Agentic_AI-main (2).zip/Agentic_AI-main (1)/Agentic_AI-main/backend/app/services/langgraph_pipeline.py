from __future__ import annotations

"""LangGraph StateGraph wiring for the agentic EWS pipeline.

Nodes: ingest → validate → features → risk → signals → recommend → notify
"""

from datetime import datetime
from typing import Any

from langgraph.graph import END, StateGraph

from app.services import ingestion, validation, features, risk, signals, recommend, notify


class PipelineState(dict):
    pass


def node_ingest(state: PipelineState) -> PipelineState:
    since: datetime | None = state.get("since")
    events = ingestion.ingest_all_sources(since)
    return {**state, "events": events}


def node_validate(state: PipelineState) -> PipelineState:
    validated = validation.validate_events(state.get("events", []))
    return {**state, "validated": validated}


def node_features(state: PipelineState) -> PipelineState:
    feats = features.build_features(state.get("validated", {}))
    return {**state, "features": feats}


def node_risk(state: PipelineState) -> PipelineState:
    risks = risk.predict_risk(state.get("features", {}))
    return {**state, "risks": risks}


def node_signals(state: PipelineState) -> PipelineState:
    sigs = signals.detect_signals(state.get("validated", {}), state.get("features", {}))
    return {**state, "signals": sigs}


def node_recommend(state: PipelineState) -> PipelineState:
    recs = recommend.recommend_interventions(state.get("risks", []), state.get("signals", {}))
    return {**state, "recommendations": recs}


def node_notify(state: PipelineState) -> PipelineState:
    result = notify.notify_educators(state.get("recommendations", []))
    return {**state, "notify_result": result}


def build_app() -> Any:
    graph = StateGraph(PipelineState)
    graph.add_node("ingest", node_ingest)
    graph.add_node("validate", node_validate)
    graph.add_node("features", node_features)
    graph.add_node("risk", node_risk)
    graph.add_node("signals", node_signals)
    graph.add_node("recommend", node_recommend)
    graph.add_node("notify", node_notify)

    graph.set_entry_point("ingest")
    graph.add_edge("ingest", "validate")
    graph.add_edge("validate", "features")
    graph.add_edge("features", "risk")
    graph.add_edge("risk", "signals")
    graph.add_edge("signals", "recommend")
    graph.add_edge("recommend", "notify")
    graph.add_edge("notify", END)
    return graph.compile()


def run_once(since: datetime | None) -> dict:
    app = build_app()
    result = app.invoke({"since": since})
    return result


