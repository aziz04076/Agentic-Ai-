from __future__ import annotations

"""Disengagement signal detection rules.
"""

from typing import Any


def detect_signals(validated: dict, features: dict) -> dict[str, list[dict]]:
    signals: dict[str, list[dict]] = {}
    vectors: dict[str, list[float]] = features.get("vectors", {})
    names = features.get("meta", {}).get("features", [])
    idx_login = names.index("login_streak_delta") if "login_streak_delta" in names else -1
    for sid, vec in vectors.items():
        s_list: list[dict] = []
        if idx_login >= 0 and vec[idx_login] <= -1.0:
            s_list.append({"type": "login_drop_7d", "magnitude": abs(vec[idx_login])})
        if s_list:
            signals[sid] = s_list
    return signals


