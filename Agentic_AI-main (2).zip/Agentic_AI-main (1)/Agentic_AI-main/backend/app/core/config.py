from __future__ import annotations

"""Application configuration using Pydantic BaseSettings (v2).

Environment variables can be provided via a `.env` file or the process env.
"""

from pydantic_settings import BaseSettings
from pydantic import Field


class Settings(BaseSettings):
    app_name: str = Field(default="ews-agentic")
    environment: str = Field(default="dev")
    api_prefix: str = Field(default="/api")
    secret_key: str = Field(default="dev-secret-change-me")
    access_token_expire_minutes: int = Field(default=60 * 24)
    cors_origins: str = Field(default="http://localhost:5173,http://localhost:3000")

    # Database
    postgres_user: str = Field(default="postgres")
    postgres_password: str = Field(default="postgres")
    postgres_db: str = Field(default="ews")
    postgres_host: str = Field(default="localhost")
    postgres_port: int = Field(default=5432)

    # Redis
    redis_url: str = Field(default="redis://localhost:6379/0")

    # Observability
    enable_metrics: bool = Field(default=True)

    class Config:
        env_file = ".env"
        env_prefix = "EWS_"

    @property
    def sqlalchemy_database_uri(self) -> str:
        return (
            f"postgresql+psycopg2://{self.postgres_user}:{self.postgres_password}"
            f"@{self.postgres_host}:{self.postgres_port}/{self.postgres_db}"
        )


settings = Settings()


