from __future__ import annotations

"""Seed demo data: ~25 students with synthetic events across 30 days."""

from datetime import datetime, timedelta, timezone
import uuid
import random

from app.db.session import session_scope
from app.db import models


def main() -> None:
    with session_scope() as db:
        # Create students
        students: list[models.Student] = []
        for i in range(25):
            sid = f"S{i+1:03d}"
            st = models.Student(id=sid, first_name=f"Student{i+1}", last_name="Demo", email=f"student{i+1}@demo.edu")
            db.add(st)
            students.append(st)

        # Create a course and enrollments
        course = models.Course(id="C001", name="Intro to EWS")
        db.add(course)
        for st in students:
            enr = models.Enrollment(id=str(uuid.uuid4()), student_id=st.id, course_id=course.id)
            db.add(enr)

        # Create events across 30 days
        base = datetime.now(tz=timezone.utc) - timedelta(days=30)
        for st in students:
            for d in range(30):
                ts = base + timedelta(days=d)
                # Attendance event
                ev_att = models.Event(
                    id=str(uuid.uuid4()),
                    student_id=st.id,
                    type="attendance",
                    timestamp=ts,
                    payload={"present": random.random() > 0.1},
                )
                db.add(ev_att)
                # LMS login event
                ev_lms = models.Event(
                    id=str(uuid.uuid4()),
                    student_id=st.id,
                    type="lms_login",
                    timestamp=ts,
                    payload={"count": random.randint(0, 3)},
                )
                db.add(ev_lms)

        # Demo educator user
        user = models.User(id=str(uuid.uuid4()), email="educator@example.com", hashed_password="demo", role="educator")
        db.add(user)

    print("Seeded demo data.")


if __name__ == "__main__":
    main()


