import pytest
from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)


def test_health_check():
    response = client.get("/healthz")
    assert response.status_code == 200
    assert response.text == "ok"


def test_metrics_endpoint():
    response = client.get("/api/metrics")
    assert response.status_code == 200


def test_login_endpoint():
    response = client.post("/api/login", json={
        "email": "educator@example.com",
        "password": "password"
    })
    assert response.status_code == 200
    data = response.json()
    assert "access_token" in data
    assert data["token_type"] == "bearer"


def test_student_risk_endpoint():
    # This would need proper auth in a real test
    response = client.get("/api/students/S001/risk")
    # Should return 401 without auth
    assert response.status_code == 401
