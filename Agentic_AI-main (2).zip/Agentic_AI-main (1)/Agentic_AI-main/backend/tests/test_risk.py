import pytest
from app.services.risk import predict_proba, calibrate, label, explain


def test_predict_proba():
    vectors = {
        "S001": [0.9, -1.0, 2.0, -0.1, 0.3, 0.7],
        "S002": [0.5, 0.0, 1.0, 0.0, 0.5, 0.5]
    }
    probs = predict_proba(vectors)
    assert "S001" in probs
    assert "S002" in probs
    assert 0 <= probs["S001"] <= 1
    assert 0 <= probs["S002"] <= 1


def test_calibrate():
    assert calibrate(0.5) == 0.5
    assert calibrate(1.5) == 1.0
    assert calibrate(-0.5) == 0.0


def test_label():
    thresholds = {"high": 0.7, "medium": 0.4}
    assert label(0.8, thresholds) == "high"
    assert label(0.5, thresholds) == "medium"
    assert label(0.3, thresholds) == "low"


def test_explain():
    vector = [0.9, -1.0, 2.0, -0.1, 0.3, 0.7]
    explanations = explain(vector)
    assert len(explanations) == 6
    assert "attendance_rate_14d" in explanations
