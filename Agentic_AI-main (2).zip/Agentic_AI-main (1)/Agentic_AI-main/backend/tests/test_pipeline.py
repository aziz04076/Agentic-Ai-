import pytest
from app.services.langgraph_pipeline import run_once


def test_pipeline_run():
    result = run_once(since=None)
    assert "events" in result
    assert "validated" in result
    assert "features" in result
    assert "risks" in result
    assert "signals" in result
    assert "recommendations" in result
    assert "notify_result" in result


def test_pipeline_with_since():
    from datetime import datetime, timezone
    since = datetime.now(timezone.utc)
    result = run_once(since=since)
    assert "events" in result
