from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from datetime import datetime, timedelta
import jwt

app = FastAPI(title="EWS Test Server")

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://localhost:5174", "http://localhost:5175", "http://localhost:5176"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

SECRET_KEY = "dev-secret-change-me"
ALGORITHM = "HS256"

@app.get("/")
def read_root():
    return {"message": "EWS Agentic is running!"}

@app.get("/healthz")
def health_check():
    return "ok"

@app.post("/api/login")
def login(credentials: dict):
    email = credentials.get("email", "")
    password = credentials.get("password", "")
    
    # Demo users - accept any non-empty password
    if not password:
        return {"error": "Invalid credentials"}
    
    # Determine role based on email
    role = "educator"
    if email.startswith("admin"):
        role = "admin"
    elif email.startswith("analyst"):
        role = "analyst"
    elif email.startswith("student"):
        role = "student"
    
    # Create JWT token
    expire = datetime.utcnow() + timedelta(hours=24)
    to_encode = {
        "sub": email,
        "role": role,
        "email": email,
        "exp": expire
    }
    token = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    
    return {
        "access_token": token,
        "token_type": "bearer"
    }

@app.get("/api/students/{student_id}/risk")
def get_student_risk(student_id: str):
    return {
        "student_id": student_id,
        "probability": 0.65,
        "label": "medium",
        "as_of_date": "2024-01-01T00:00:00Z",
        "model_version": "baseline-0.1",
        "explanations": {"attendance_rate_14d": 0.9}
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)
