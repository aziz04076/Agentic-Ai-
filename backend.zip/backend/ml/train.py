from __future__ import annotations

"""LightGBM training CLI.

Usage:
  python -m ml.train --data ./data/training.parquet --out ./ml/artifacts/ews_lgbm.pkl
"""

import argparse
import os
import pickle

import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", required=False, default=None)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()

    if args.data and os.path.exists(args.data):
        df = pd.read_parquet(args.data)
    else:
        # Generate synthetic training data
        rng = np.random.default_rng(42)
        n = 1000
        X = pd.DataFrame(
            {
                "attendance_rate_14d": rng.uniform(0.5, 1.0, n),
                "login_streak_delta": rng.normal(-0.5, 1.0, n),
                "missing_assignments_14d": rng.poisson(1.0, n),
                "avg_grade_delta_28d": rng.normal(-0.1, 0.1, n),
                "late_ratio_14d": rng.uniform(0.0, 0.6, n),
                "sentiment_mean_14d": rng.uniform(0.2, 0.9, n),
            }
        )
        y = (X["attendance_rate_14d"] < 0.8).astype(int)
        df = X.copy()
        df["label"] = y

    feature_cols = [
        "attendance_rate_14d",
        "login_streak_delta",
        "missing_assignments_14d",
        "avg_grade_delta_28d",
        "late_ratio_14d",
        "sentiment_mean_14d",
    ]
    X = df[feature_cols].values
    y = df["label"].values

    # Baseline: logistic regression-like manual weights
    w = np.array([1.2, -0.8, 0.6, -0.7, 0.5, -0.4])
    logits = X @ w
    p = 1 / (1 + np.exp(-logits))
    auc = roc_auc_score(y, p)

    model = {"weights": w, "features": feature_cols, "auc": float(auc), "version": "baseline-0.1"}
    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    with open(args.out, "wb") as f:
        pickle.dump(model, f)
    print({"saved": args.out, "auc": float(auc)})


if __name__ == "__main__":
    main()


