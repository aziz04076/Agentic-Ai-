from __future__ import annotations

"""FastAPI dependencies: DB session, JWT auth, and role-based access.
"""

from typing import Annotated, Generator, Optional

from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session

from app.core.auth import decode_token
from app.db.session import SessionLocal


oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/login")


def get_db() -> Generator[Session, None, None]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def get_current_user(token: Annotated[str, Depends(oauth2_scheme)]) -> dict:
    try:
        payload = decode_token(token)
        return payload
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials") from exc


def require_role(required: str):
    def _dep(user: Annotated[dict, Depends(get_current_user)]) -> dict:
        role = user.get("role")
        if role != required and role != "admin":
            raise HTTPException(status_code=403, detail="Insufficient role")
        return user

    return _dep


