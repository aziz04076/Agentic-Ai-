from __future__ import annotations

from fastapi import APIRouter, Depends

from app.deps import require_role
from app.db.schemas import InterventionIn, InterventionOut

router = APIRouter(tags=["interventions"])


@router.post("/interventions", response_model=InterventionOut)
def create_intervention(payload: InterventionIn, _: dict = Depends(require_role("educator"))):
    """
    Example request:
    {"student_id":"s1","subject":"Support plan","body":"..."}
    """
    return InterventionOut(id="iv-1", status="draft", created_at="2024-01-01T00:00:00Z", **payload.model_dump())


