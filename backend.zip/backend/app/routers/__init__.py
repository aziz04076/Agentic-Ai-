from app.routers.ingest import router as ingest  # type: ignore
from app.routers.predict import router as predict  # type: ignore
from app.routers.students import router as students  # type: ignore
from app.routers.interventions import router as interventions  # type: ignore
from app.routers.feedback import router as feedback  # type: ignore
from app.routers.alerts import router as alerts  # type: ignore


