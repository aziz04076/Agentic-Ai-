from __future__ import annotations

from fastapi import APIRouter, Depends

from app.deps import require_role
from app.services.feedback import log_outcome

router = APIRouter(tags=["feedback"])


@router.post("/feedback")
def post_feedback(payload: dict, _: dict = Depends(require_role("educator"))):
    """
    Example request: {"intervention_id":"iv-1","outcome":"positive","notes":"..."}
    """
    return log_outcome(payload.get("intervention_id", "iv-1"), payload.get("outcome", "unknown"), payload.get("notes"))


