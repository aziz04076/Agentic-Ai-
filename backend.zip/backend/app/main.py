from __future__ import annotations

"""FastAPI application factory and startup wiring.

Endpoints will be registered from `app.routers`. WebSocket, metrics, and health
checks are included. JWT utilities live in `app.core.auth`. This file is kept
minimal to avoid import cycles.
"""

from datetime import datetime
from typing import Annotated

from fastapi import Depends, FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import PlainTextResponse

from prometheus_client import CONTENT_TYPE_LATEST, CollectorRegistry, Counter, generate_latest

from app.core.config import settings


registry = CollectorRegistry()
REQUESTS_COUNTER = Counter(
    "requests_total",
    "Total HTTP requests",
    ["method", "path", "status"],
    registry=registry,
)


def create_app() -> FastAPI:
    app = FastAPI(title=settings.app_name)

    # CORS
    origins = [o.strip() for o in settings.cors_origins.split(",") if o.strip()]
    app.add_middleware(
        CORSMiddleware,
        allow_origins=origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Basic health
    @app.get("/healthz", summary="Health check", response_class=PlainTextResponse)
    def healthz() -> str:
        return "ok"

    # Metrics endpoint (Prometheus)
    @app.get("/api/metrics", summary="Prometheus metrics")
    def metrics() -> PlainTextResponse:
        if not settings.enable_metrics:
            return PlainTextResponse("", media_type=CONTENT_TYPE_LATEST)
        data = generate_latest(registry)
        return PlainTextResponse(data, media_type=CONTENT_TYPE_LATEST)

    # Routers - temporarily commented out for initial setup
    # from app.routers import ingest, predict, students, interventions, feedback, alerts
    # from app.routers.auth import router as auth_router
    # app.include_router(ingest, prefix=settings.api_prefix)
    # app.include_router(predict, prefix=settings.api_prefix)
    # app.include_router(students, prefix=settings.api_prefix)
    # app.include_router(interventions, prefix=settings.api_prefix)
    # app.include_router(feedback, prefix=settings.api_prefix)
    # app.include_router(alerts, prefix=settings.api_prefix)
    # app.include_router(auth_router, prefix=settings.api_prefix)

    return app


app = create_app()


