from __future__ import annotations

"""RQ worker and Redis connection setup."""

import redis
from rq import Queue

from app.core.config import settings


redis_conn = redis.from_url(settings.redis_url)
queue = Queue("ews", connection=redis_conn)


def enqueue_job(func, *args, **kwargs):
    return queue.enqueue(func, *args, **kwargs)


