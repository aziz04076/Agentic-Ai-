from __future__ import annotations

"""Feedback loop services for post-intervention outcomes and retraining triggers."""


def log_outcome(intervention_id: str, outcome: str, notes: str | None) -> dict:
    return {"intervention_id": intervention_id, "outcome": outcome, "notes": notes}


def update_playbook_metrics() -> None:
    return None


def trigger_retrain_if_needed() -> None:
    return None


