from __future__ import annotations

"""Risk model prediction services.

Implements minimal LightGBM placeholder with deterministic outputs.
"""

from datetime import datetime, timezone
from typing import Any


def load_model(version: str | None) -> Any:
    return {"version": version or "baseline-0.1"}


def predict_proba(vectors: dict[str, list[float]]) -> dict[str, float]:
    # Simple heuristic: probability is sigmoid of sum of features scaled
    import math

    probs: dict[str, float] = {}
    for sid, vec in vectors.items():
        s = sum(vec)
        p = 1 / (1 + math.exp(-s / 10))
        probs[sid] = float(p)
    return probs


def calibrate(p: float) -> float:
    return min(max(p, 0.0), 1.0)


def label(p: float, thresholds: dict) -> str:
    if p >= thresholds.get("high", 0.7):
        return "high"
    if p >= thresholds.get("medium", 0.4):
        return "medium"
    return "low"


def explain(vector: list[float]) -> dict:
    names = [
        "attendance_rate_14d",
        "login_streak_delta",
        "missing_assignments_14d",
        "avg_grade_delta_28d",
        "late_ratio_14d",
        "sentiment_mean_14d",
    ]
    return {k: float(v) for k, v in zip(names, vector)}


def predict_risk(features: dict) -> list[dict]:
    vectors: dict[str, list[float]] = features.get("vectors", {})
    probs = predict_proba(vectors)
    out: list[dict] = []
    model = load_model(None)
    as_of = datetime.now(tz=timezone.utc)
    for sid, p in probs.items():
        pc = calibrate(p)
        lbl = label(pc, {"high": 0.7, "medium": 0.4})
        out.append(
            {
                "student_id": sid,
                "probability": pc,
                "label": lbl,
                "explanations": explain(vectors[sid]),
                "as_of_date": as_of,
                "model_version": model["version"],
            }
        )
    return out


