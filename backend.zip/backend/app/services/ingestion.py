from __future__ import annotations

"""Data ingestion services.

All functions return simple deterministic stubs suitable for initial wiring.
"""

from datetime import datetime, timedelta, timezone
from typing import Any

EventDict = dict[str, Any]


def fetch_sis_grades(since: datetime) -> list[EventDict]:
    return []


def fetch_lms_activity(since: datetime) -> list[EventDict]:
    return []


def fetch_assessments(since: datetime) -> list[EventDict]:
    return []


def validate_event_schema(event: dict) -> dict:
    return event


def dedupe_and_order(events: list[dict]) -> list[dict]:
    return sorted(events, key=lambda e: e.get("timestamp"))


def ingest_all_sources(since: datetime | None) -> list[dict]:
    base = since or datetime.now(tz=timezone.utc) - timedelta(days=1)
    events = []
    events += fetch_sis_grades(base)
    events += fetch_lms_activity(base)
    events += fetch_assessments(base)
    events = [validate_event_schema(e) for e in events]
    return dedupe_and_order(events)


