from __future__ import annotations

"""Feature engineering services.
"""

from collections import defaultdict
from typing import Any


def compute_attendance_features(events: list[dict]) -> dict[str, dict]:
    by_student: dict[str, dict] = defaultdict(dict)
    for e in events:
        sid = e.get("student_id")
        if not sid:
            continue
        by_student[sid]["attendance_rate_14d"] = 0.9
    return by_student


def compute_lms_engagement(events: list[dict]) -> dict:
    return {e.get("student_id"): {"login_streak_delta": -1.0} for e in events if e.get("student_id")}


def grade_trend_features(events: list[dict]) -> dict:
    return {e.get("student_id"): {"avg_grade_delta_28d": -0.05} for e in events if e.get("student_id")}


def assignment_timeliness(events: list[dict]) -> dict:
    return {e.get("student_id"): {"missing_assignments_14d": 1, "late_ratio_14d": 0.2} for e in events if e.get("student_id")}


def sentiment_features(events: list[dict]) -> dict:
    return {e.get("student_id"): {"sentiment_mean_14d": 0.6} for e in events if e.get("student_id")}


def build_features(validated: dict) -> dict:
    events = validated.get("events", [])
    feat_maps = [
        compute_attendance_features(events),
        compute_lms_engagement(events),
        grade_trend_features(events),
        assignment_timeliness(events),
        sentiment_features(events),
    ]
    all_keys = [
        "attendance_rate_14d",
        "login_streak_delta",
        "missing_assignments_14d",
        "avg_grade_delta_28d",
        "late_ratio_14d",
        "sentiment_mean_14d",
    ]
    vectors: dict[str, list[float]] = {}
    meta: dict[str, Any] = {"features": all_keys}
    student_ids = {sid for m in feat_maps for sid in m.keys()}
    for sid in student_ids:
        row: dict[str, float] = {}
        for m in feat_maps:
            row.update(m.get(sid, {}))
        vectors[sid] = [float(row.get(k, 0.0)) for k in all_keys]
    return {"vectors": vectors, "meta": meta}


