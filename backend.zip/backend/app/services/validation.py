from __future__ import annotations

"""Validation, PII scrubbing, and ID resolution services.
"""

from typing import Any


def scrub_pii(event: dict) -> dict:
    event = dict(event)
    event.get("payload", {}).pop("ssn", None)
    return event


def flag_outliers(event: dict) -> dict | None:
    return event


def resolve_student_id(event: dict) -> str | None:
    return event.get("student_id")


def validate_events(events: list[dict]) -> dict:
    valid: list[dict] = []
    issues: list[dict] = []
    for e in events:
        e2 = scrub_pii(e)
        sid = resolve_student_id(e2)
        if not sid:
            issues.append({"event": e2, "issue": "missing_student_id"})
            continue
        if flag_outliers(e2) is None:
            issues.append({"event": e2, "issue": "outlier"})
            continue
        valid.append(e2)
    return {"events": valid, "issues": issues}


