from __future__ import annotations

"""Pydantic v2 models for API requests/responses.
"""

from datetime import datetime
from typing import Any, Optional

from pydantic import BaseModel, Field


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"


class LoginRequest(BaseModel):
    email: str
    password: str


class StudentOut(BaseModel):
    id: str
    first_name: str
    last_name: str


class RiskOut(BaseModel):
    student_id: str
    probability: float
    label: str
    as_of_date: datetime
    model_version: str
    explanations: dict[str, float]


class EventIn(BaseModel):
    student_id: str
    type: str
    timestamp: datetime
    payload: dict[str, Any] = Field(default_factory=dict)


class InterventionIn(BaseModel):
    student_id: str
    subject: str
    body: str


class InterventionOut(InterventionIn):
    id: str
    status: str
    created_at: datetime


class FeedbackIn(BaseModel):
    intervention_id: str
    outcome: str
    notes: Optional[str] = None


